﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim myg As Graphics = Me.CreateGraphics

        Dim myb1 As New System.Drawing.SolidBrush(System.Drawing.Color.Red)
        Dim myb2 As New System.Drawing.SolidBrush(System.Drawing.Color.Blue)

        myg.FillRectangle(myb1, New Rectangle(10, 100, 100, 100))
        myg.FillEllipse(myb2, New Rectangle(150, 100, 100, 100))

        myb1.Dispose()
        myb2.Dispose()
    End Sub
End Class
