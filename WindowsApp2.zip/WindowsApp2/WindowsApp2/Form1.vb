﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With ComboBox1
            .Items.Add("NoAnchor")
            .Items.Add("ArrowAnchor")
            .Items.Add("DiamondAnchor")
            .Items.Add("RoundAnchor")
            .Items.Add("SquareAnchor")
            .Items.Add("Flat")
            .Items.Add("Round")
            .Items.Add("Square")
            .Items.Add("Triangle")
        End With
        ComboBox1.SelectedIndex = 0

        With ComboBox2
            .Items.Add("NoAnchor")
            .Items.Add("ArrowAnchor")
            .Items.Add("DiamondAnchor")
            .Items.Add("RoundAnchor")
            .Items.Add("SquareAnchor")
            .Items.Add("Flat")
            .Items.Add("Round")
            .Items.Add("Square")
            .Items.Add("Triangle")
        End With
        ComboBox2.SelectedIndex = 0
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim gra As Graphics = PictureBox1.CreateGraphics
        Dim mp As System.Drawing.Pen
        mp = New Pen(Color.Black, 3)

        If RadioButton1.Checked = True Then
            mp.DashStyle = Drawing2D.DashStyle.Solid
        End If

        If RadioButton2.Checked = True Then
            mp.DashStyle = Drawing2D.DashStyle.Dash
        End If

        If RadioButton3.Checked = True Then
            mp.DashStyle = Drawing2D.DashStyle.Dot
        End If

        If RadioButton4.Checked = True Then
            mp.DashStyle = Drawing2D.DashStyle.DashDot
        End If

        If RadioButton5.Checked = True Then
            mp.DashStyle = Drawing2D.DashStyle.DashDotDot
        End If

        If RadioButton11.Checked = True Then
            mp.Color = Color.Red
        End If

        If RadioButton12.Checked = True Then
            mp.Color = Color.Blue
        End If

        If RadioButton13.Checked = True Then
            mp.Color = Color.Green
        End If

        If RadioButton14.Checked = True Then
            mp.Color = Color.Purple
        End If

        If RadioButton15.Checked = True Then
            mp.Color = Color.Magenta
        End If

        Select Case ComboBox1.SelectedIndex
            Case 0
                mp.StartCap = Drawing2D.LineCap.NoAnchor
            Case 1
                mp.StartCap = Drawing2D.LineCap.ArrowAnchor
            Case 2
                mp.StartCap = Drawing2D.LineCap.DiamondAnchor
            Case 3
                mp.StartCap = Drawing2D.LineCap.RoundAnchor
            Case 4
                mp.StartCap = Drawing2D.LineCap.SquareAnchor
            Case 5
                mp.StartCap = Drawing2D.LineCap.Flat
            Case 6
                mp.StartCap = Drawing2D.LineCap.Round
            Case 7
                mp.StartCap = Drawing2D.LineCap.Square
            Case 8
                mp.StartCap = Drawing2D.LineCap.Triangle
        End Select

        Select Case ComboBox2.SelectedIndex
            Case 0
                mp.StartCap = Drawing2D.LineCap.NoAnchor
            Case 1
                mp.StartCap = Drawing2D.LineCap.ArrowAnchor
            Case 2
                mp.StartCap = Drawing2D.LineCap.DiamondAnchor
            Case 3
                mp.StartCap = Drawing2D.LineCap.RoundAnchor
            Case 4
                mp.StartCap = Drawing2D.LineCap.SquareAnchor
            Case 5
                mp.StartCap = Drawing2D.LineCap.Flat
            Case 6
                mp.StartCap = Drawing2D.LineCap.Round
            Case 7
                mp.StartCap = Drawing2D.LineCap.Square
            Case 8
                mp.StartCap = Drawing2D.LineCap.Triangle
        End Select

        If RadioButton6.Checked = True Then
            mp.DashCap = Drawing2D.DashCap.Flat
        End If

        If RadioButton7.Checked = True Then
            mp.DashCap = Drawing2D.DashCap.Round
        End If

        If RadioButton8.Checked = True Then
            mp.DashCap = Drawing2D.DashCap.Triangle
        End If

        gra.DrawLine(mp, 10, 10, 100, 100)
        mp.Dispose()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim mg As Graphics = PictureBox1.CreateGraphics
        Dim mp As System.Drawing.Pen
        Dim recw, rech As Integer

        recw = Val(TextBox1.Text)
        rech = Val(TextBox2.Text)
        mp = New Pen(Color.Black, 3)
        mg.DrawRectangle(mp, New Rectangle(10, 10, recw, rech))
        mp.Dispose()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim myg As Graphics = PictureBox1.CreateGraphics
        Dim ppen As System.Drawing.Pen
        Dim wi, he As Integer

        wi = Val(TextBox1.Text)
        he = Val(TextBox2.Text)
        ppen = New Pen(Color.Black, 3)
        myg.DrawEllipse(ppen, New Rectangle(10, 10, wi, he))
        ppen.Dispose()
    End Sub
End Class
