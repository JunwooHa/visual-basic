﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim img As New System.Drawing.Drawing2D.LinearGradientBrush(
            New Point(0, 10), New Point(200, 10),
            Color.FromArgb(255, 255, 0, 0),
            Color.FromArgb(255, 0, 0, 255))
        Dim mg As Graphics = Me.CreateGraphics()
        Dim pen As New Pen(img, 4)

        mg.DrawLine(pen, 0, 10, 200, 10)
        mg.FillEllipse(img, 0, 30, 200, 100)
        mg.FillRectangle(img, 0, 155, 300, 50)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim img1 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Point(0, 10), New Point(200, 10),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255))
        Dim img2 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Point(0, 10), New Point(200, 10),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255))
        Dim grap As Graphics = Me.CreateGraphics()

        grap.FillRectangle(img1, 20, 30, 200, 100)
        grap.FillRectangle(img2, 20, 155, 300, 50)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim img1 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Point(0, 10), New Point(200, 10),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255))
        Dim img2 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Rectangle(5, 5, 50, 50),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255),
           linearGradientMode:=Drawing2D.LinearGradientMode.BackwardDiagonal)
        Dim img3 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Rectangle(5, 5, 50, 50),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255),
           linearGradientMode:=Drawing2D.LinearGradientMode.ForwardDiagonal)
        Dim img4 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Rectangle(5, 5, 50, 50),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255),
           linearGradientMode:=Drawing2D.LinearGradientMode.Vertical)
        Dim img5 As New System.Drawing.Drawing2D.LinearGradientBrush(
           New Rectangle(5, 5, 50, 50),
           Color.FromArgb(255, 255, 0, 0),
           Color.FromArgb(255, 0, 0, 255),
           linearGradientMode:=Drawing2D.LinearGradientMode.Horizontal)
        Dim mg As Graphics = Me.CreateGraphics()

        mg.FillRectangle(img1, 20, 30, 200, 100)
        mg.FillRectangle(img2, 250, 160, 200, 100)
        mg.FillRectangle(img3, 480, 160, 200, 100)
        mg.FillRectangle(img4, 710, 160, 200, 100)
    End Sub
End Class
