﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With ComboBox1
            .Items.Add("NoAnchor")
            .Items.Add("ArrowAnchor")
            .Items.Add("DiamondAnchor")
            .Items.Add("RoundAnchor")
            .Items.Add("SquareAnchor")
            .Items.Add("Flat")
            .Items.Add("Round")
            .Items.Add("Square")
            .Items.Add("Triangle")
        End With
        ComboBox1.SelectedIndex = 0

        With ComboBox2
            .Items.Add("NoAnchor")
            .Items.Add("ArrowAnchor")
            .Items.Add("DiamondAnchor")
            .Items.Add("RoundAnchor")
            .Items.Add("SquareAnchor")
            .Items.Add("Flat")
            .Items.Add("Round")
            .Items.Add("Square")
            .Items.Add("Triangle")
        End With
        ComboBox2.SelectedIndex = 0
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim mg As Graphics = PictureBox1.CreateGraphics
        Dim mp As System.Drawing.Pen
        Dim recw, rech As Integer

        recw = Val(TextBox1.Text)
        rech = Val(TextBox2.Text)
        mp = New Pen(Color.Black, 3)
        mg.DrawRectangle(mp, New Rectangle(10, 10, recw, rech))
        mp.Dispose()
    End Sub
End Class
