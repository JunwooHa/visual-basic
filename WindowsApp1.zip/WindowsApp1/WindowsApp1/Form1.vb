﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With CheckedListBox1
            .Items.Add("수박")
            .Items.Add("감자")
            .Items.Add("참외")
            .Items.Add("배추")
            .Items.Add("자두")
            .Items.Add("토마토")
            .Items.Add("딸기")
            .Items.Add("옥수수")
            .Items.Add("메론")
            .Items.Add("양파")
        End With
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i, k, cnt As Integer
        cnt = CheckedListBox1.Items.Count
        k = 0
        For i = 1 To cnt
            If CheckedListBox1.GetItemChecked(k) Then
                CheckedListBox2.Items.Add(CheckedListBox1.Items.Item(k))
                CheckedListBox1.Items.RemoveAt(k)
            Else
                k += 1
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim i, k, cnt As Integer
        cnt = CheckedListBox2.Items.Count
        k = 0
        For i = 1 To cnt
            If CheckedListBox2.GetItemChecked(k) Then
                CheckedListBox1.Items.Add(CheckedListBox2.Items.Item(k))
                CheckedListBox2.Items.RemoveAt(k)
            Else
                k += 1
            End If
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label3.Text = CheckedListBox1.Items.Count
    End Sub
End Class
