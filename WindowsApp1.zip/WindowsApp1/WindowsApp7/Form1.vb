﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.SelectedIndex = 0
        ListView1.LargeImageList = ImageList1
        ListView1.View = View.LargeIcon
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedIndex = 0 Then
            ListView1.LargeImageList = ImageList1
            ListView1.View = View.LargeIcon
        ElseIf ListBox1.SelectedIndex = 1 Then
            ListView1.SmallImageList = ImageList1
            ListView1.View = View.SmallIcon
        ElseIf ListBox1.SelectedIndex = 2 Then
            ListView1.SmallImageList = ImageList1
            ListView1.View = View.List
        ElseIf ListBox1.SelectedIndex = 3 Then
            ListView1.SmallImageList = ImageList1
            ListView1.View = View.Details
        ElseIf ListBox1.SelectedIndex = 4 Then
            ListView1.SmallImageList = ImageList1
            ListView1.View = View.Tile
        End If
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Dim i As Integer

        For i = 1 To ListView1.Items.Count - 1
            If ListView1.Items(i).Selected = True Then
                MsgBox(ListView1.Items(i).Text, MsgBoxStyle.Information, "확인")
                Exit For
            End If
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub
End Class
